﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace Qizmt_ADONET_Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.Error.WriteLine("Qizmt_ADONET_Sample.exe expects arguments: <connectionString> [query statement]");
                return;            
            }

            string connstr = args[0].Trim();
            string sql = "";

            if (args.Length > 1)
            {
                sql = args[1].Trim();
            }

            try
            {
                System.Data.Common.DbProviderFactory fact = DbProviderFactories.GetFactory("Qizmt_DataProvider");
                using (DbConnection conn = fact.CreateConnection())
                {
                    conn.ConnectionString = connstr;
                    conn.Open();
                    Console.WriteLine("Opening connection...");
                    Console.WriteLine("Connected successfully.");

                    if (sql.Length > 0)
                    {
                        Console.WriteLine("Executing query...");
                        DbCommand cmd = conn.CreateCommand();
                        cmd.CommandText = sql;
                        DbDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                        }
                        reader.Close();
                        Console.WriteLine("Query executed successfully.");
                    }
                    conn.Close();
                }              
            }
            catch (Exception e)
            {
                Console.Error.WriteLine("Error: " + e.ToString());
            }
        }
    }
}
